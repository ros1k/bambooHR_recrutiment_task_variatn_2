<?php get_header();
?>
    <div id="primary" class="content-area">
<?php include 'partials/page-header.php'; ?>
    <main id="main" class="site-main" role="main">

<?php
wp_reset_query();
get_footer();
