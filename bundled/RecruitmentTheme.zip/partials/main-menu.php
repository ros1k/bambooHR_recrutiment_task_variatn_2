<div class="container">
    <div class="row">
        <div class="col-12 p-0">
            <nav class="navbar align-items-center  justify-content-between navbar-light p-0">
                <div class="col-2 col-sm-2 col-md-2  logo-wrap">
                    <a href="<?php echo get_site_url() ;?>" title="recruitment task">
                        <img class="logo" src="<?php the_field('logo','option'); ?>" alt="<?php bloginfo('name'); ?>"/>
                    </a>
                </div>
              
            </nav>
        </div>
    </div>
</div>
